# SkyCast — Weather Dashboard 🌤️

A clean, responsive weather dashboard built with **HTML, CSS, and JavaScript** using the OpenWeatherMap API.

![SkyCast Preview](preview.png)

## Features

- **Current weather** — Temperature, feels like, humidity, wind speed, pressure, visibility
- **5-day forecast** — Daily high/low temperatures with weather conditions
- **City search** — Search any city worldwide
- **Quick cities** — One-click popular cities
- **Responsive design** — Works on mobile, tablet, and desktop
- **Error handling** — Friendly messages for invalid cities or network issues

## Tech Stack

- HTML5
- CSS3 (CSS Variables, Grid, Flexbox)
- Vanilla JavaScript (Fetch API, async/await)
- [OpenWeatherMap API](https://openweathermap.org/api)

## Getting Started

### 1. Get a Free API Key

1. Go to [openweathermap.org](https://openweathermap.org/)
2. Click **Sign Up** (it's free)
3. After signing up, go to **My Profile → API Keys**
4. Copy your API key

> Note: New API keys take up to 10 minutes to activate.

### 2. Clone the Repository

```bash
git clone https://github.com/YOUR_USERNAME/weather-dashboard.git
cd weather-dashboard
```

### 3. Add Your API Key

Open `app.js` and replace the placeholder with your key:

```js
const API_KEY = "YOUR_API_KEY_HERE"; // Replace this
```

### 4. Run the Project

Simply open `index.html` in your browser — no build tools or npm needed!

Or use VS Code's **Live Server** extension for auto-reload.

## Project Structure

```
weather-dashboard/
├── index.html     # Main HTML structure
├── style.css      # All styling
├── app.js         # API calls and DOM logic
└── README.md      # This file
```

## Live Demo

[View Live Demo](https://YOUR_USERNAME.github.io/weather-dashboard)

## API Reference

This project uses two OpenWeatherMap endpoints:

| Endpoint | Purpose |
|---|---|
| `/weather` | Current weather data |
| `/forecast` | 5-day / 3-hour forecast |

## License

MIT — free to use for learning and personal projects.
