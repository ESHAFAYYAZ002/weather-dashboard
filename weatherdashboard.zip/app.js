// ─── CONFIG ──────────────────────────────────────────────
// Get your FREE API key from: https://openweathermap.org/api
// 1. Sign up at openweathermap.org
// 2. Go to "My API Keys" section
// 3. Copy your key and paste it below
const API_KEY = "YOUR_API_KEY_HERE"; // <-- Replace this!
const BASE_URL = "https://api.openweathermap.org/data/2.5";

// ─── DOM ELEMENTS ─────────────────────────────────────────
const cityInput    = document.getElementById("cityInput");
const searchBtn    = document.getElementById("searchBtn");
const loader       = document.getElementById("loader");
const mainContent  = document.getElementById("mainContent");
const welcomeState = document.getElementById("welcomeState");
const errorBanner  = document.getElementById("errorBanner");
const errorText    = document.getElementById("errorText");

// Current weather elements
const cityName     = document.getElementById("cityName");
const countryDate  = document.getElementById("countryDate");
const bigTemp      = document.getElementById("bigTemp");
const conditionText= document.getElementById("conditionText");
const weatherIcon  = document.getElementById("weatherIcon");
const feelsLike    = document.getElementById("feelsLike");
const humidity     = document.getElementById("humidity");
const windSpeed    = document.getElementById("windSpeed");
const pressure     = document.getElementById("pressure");
const visibility   = document.getElementById("visibility");
const forecastGrid = document.getElementById("forecastGrid");

// ─── EVENTS ────────────────────────────────────────────────
searchBtn.addEventListener("click", () => {
  const city = cityInput.value.trim();
  if (city) fetchWeather(city);
});

cityInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    const city = cityInput.value.trim();
    if (city) fetchWeather(city);
  }
});

// ─── MAIN FETCH FUNCTION ───────────────────────────────────
async function fetchWeather(city) {
  showLoader();

  // Check if API key is set
  if (API_KEY === "YOUR_API_KEY_HERE") {
    showError("Please add your OpenWeatherMap API key in app.js file.");
    return;
  }

  try {
    // Fetch current weather
    const currentRes = await fetch(
      `${BASE_URL}/weather?q=${encodeURIComponent(city)}&appid=${API_KEY}&units=metric`
    );

    if (!currentRes.ok) {
      if (currentRes.status === 404) {
        showError(`"${city}" city not found. Please check the spelling.`);
      } else if (currentRes.status === 401) {
        showError("Invalid API key. Please check your key in app.js.");
      } else {
        showError("Something went wrong. Please try again.");
      }
      return;
    }

    const currentData = await currentRes.json();

    // Fetch 5-day forecast
    const forecastRes = await fetch(
      `${BASE_URL}/forecast?q=${encodeURIComponent(city)}&appid=${API_KEY}&units=metric`
    );
    const forecastData = await forecastRes.json();

    displayCurrentWeather(currentData);
    displayForecast(forecastData);
    showMain();

  } catch (err) {
    showError("Network error. Please check your internet connection.");
    console.error(err);
  }
}

// ─── DISPLAY CURRENT WEATHER ──────────────────────────────
function displayCurrentWeather(data) {
  const { name, sys, main, weather, wind, visibility: vis } = data;

  cityName.textContent     = name;
  countryDate.textContent  = `${sys.country} · ${getFormattedDate()}`;
  bigTemp.textContent      = Math.round(main.temp);
  conditionText.textContent= weather[0].description;
  feelsLike.textContent    = `${Math.round(main.feels_like)}°C`;
  humidity.textContent     = `${main.humidity}%`;
  windSpeed.textContent    = `${Math.round(wind.speed * 3.6)} km/h`; // m/s to km/h
  pressure.textContent     = `${main.pressure} hPa`;
  visibility.textContent   = `${(vis / 1000).toFixed(1)} km`;

  const iconCode = weather[0].icon;
  weatherIcon.src = `https://openweathermap.org/img/wn/${iconCode}@2x.png`;
  weatherIcon.alt = weather[0].description;
}

// ─── DISPLAY 5-DAY FORECAST ───────────────────────────────
function displayForecast(data) {
  // Group forecasts by day — take one reading per day (noon time)
  const daily = {};

  data.list.forEach(item => {
    const date  = new Date(item.dt * 1000);
    const day   = date.toDateString();
    const hour  = date.getHours();

    // Prefer readings near 12pm, else take first of the day
    if (!daily[day] || Math.abs(hour - 12) < Math.abs(new Date(daily[day].dt * 1000).getHours() - 12)) {
      daily[day] = item;
    }
  });

  const days = Object.values(daily).slice(0, 5);
  forecastGrid.innerHTML = "";

  days.forEach(item => {
    const date   = new Date(item.dt * 1000);
    const dayStr = date.toLocaleDateString("en-US", { weekday: "short" });
    const icon   = item.weather[0].icon;
    const desc   = item.weather[0].description;
    const high   = Math.round(item.main.temp_max);
    const low    = Math.round(item.main.temp_min);

    const card = document.createElement("div");
    card.className = "forecast-card";
    card.innerHTML = `
      <p class="forecast-day">${dayStr}</p>
      <img class="forecast-icon" src="https://openweathermap.org/img/wn/${icon}@2x.png" alt="${desc}" />
      <p class="forecast-temp-high">${high}°</p>
      <p class="forecast-temp-low">${low}°</p>
      <p class="forecast-desc">${desc}</p>
    `;
    forecastGrid.appendChild(card);
  });
}

// ─── UI STATE HELPERS ─────────────────────────────────────
function showLoader() {
  hideError();
  loader.style.display       = "flex";
  mainContent.style.display  = "none";
  welcomeState.style.display = "none";
}

function showMain() {
  loader.style.display       = "none";
  mainContent.style.display  = "flex";
  welcomeState.style.display = "none";
}

function showError(msg) {
  loader.style.display       = "none";
  mainContent.style.display  = "none";
  welcomeState.style.display = "flex";
  errorBanner.style.display  = "block";
  errorText.textContent      = msg;
}

function hideError() {
  errorBanner.style.display = "none";
}

// ─── UTILS ────────────────────────────────────────────────
function getFormattedDate() {
  return new Date().toLocaleDateString("en-US", {
    weekday: "long",
    month:   "long",
    day:     "numeric",
    year:    "numeric"
  });
}
